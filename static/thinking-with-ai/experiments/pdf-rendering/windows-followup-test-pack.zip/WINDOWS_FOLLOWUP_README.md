# Windows PDF follow-up — 2026-10-09

The original A/B/C/D variants were all unusably slow in Windows Acrobat. A was also slow in Edge/PDFium and Foxit Reader,
so the defect is not Acrobat-specific. Raster H remained fast.

These cells test whether the pervasive component-level transparency/effects left by the original experiment are the cause.
The deck's CSS contains 133 `rgba()` uses and 10 box shadows; C/D had flattened only the three viewport gradients.

| Cell | Font | Component alpha/shadows | Background gradients/images | Bytes | Type 3 | Shadings | Patterns | ExtGState | URI |
|---|---|---|---|---:|---:|---:|---:|---:|---:|
| J | variable | removed/opaque | one background image; other gradients remain | 2,571,695 | 325 | 270 | 712 | 130 | 10 |
| K | static | removed/opaque | one background image; other gradients remain | 1,040,834 | 1 | 270 | 712 | 130 | 10 |
| L | variable | removed/opaque | all CSS background images/gradients removed | 2,256,870 | 325 | 2 | 3 | 26 | 10 |
| M | static | removed/opaque | all CSS background images/gradients removed | 727,043 | 1 | 2 | 3 | 26 | 10 |
| I | Ghostscript rewrite of A | original appearance | live transparency retained, rewritten producer | 1,940,502 | 547 | 56 | 488 | 355 | 10 |

J/K/L/M preserve text and ten URI annotations. They are diagnostic and visually simplified, not production candidates.
Ghostscript PDF 1.3 cell G forced transparency flattening but rasterized every complete page because page-wide transparency
overlaps the whole slide: 20.7 MB, no fonts, no searchable text, and no URI annotations. It is dominated by H and omitted
from this pack. PDF 1.4 cell I preserves text/links and changes the object graph, but increases Type 3/ExtGState counts; it is
included only as a different-producer control.

On the same Windows machine, open I/J/K/L/M in Acrobat, Edge, or Foxit and classify cold page rendering as usable/unusable.
Interpretation:

- K fast, J slow: Type 3 interacts with the remaining gradients/patterns.
- L/M fast: pervasive CSS gradients/transparency/effects are the main cost.
- M fast, L slow: Type 3 and effects both matter.
- M still slow: inspect remaining path/content complexity or switch PDF producer/flattening engine.

A separate Ghostscript run is rewriting A through `pdfwrite`: PDF 1.3 forces transparency flattening; PDF 1.4 tests a clean
rewrite while retaining live transparency. Those outputs will be added when complete.
