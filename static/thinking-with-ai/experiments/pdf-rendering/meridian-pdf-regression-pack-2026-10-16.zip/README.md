# Meridian PDF Windows regression retest — 2026-10-16

## Purpose

The published PDF became slow again in Windows Acrobat after later slide revisions. The live bytes exactly match local production;
this pack distinguishes three explanations:

1. the published PDF accidentally retained vector-gradient machinery;
2. the current slide content introduced another rendering cost;
3. Acrobat or the Windows environment changed since the original test.

## Files

| File | Deck state | Print background | Prior status | Type 3 | Shadings | Patterns | ExtGState | URI |
|---|---|---|---|---:|---:|---:|---:|---:|
| `00-current-public-known-slow.pdf` | current | production: raster `.pdf-page`, vector-gradient viewport remains | slow on 2026-10-14 | 328 | 22 | 72 | 103 | 12 |
| `01-historical-P-known-usable.pdf` | 2026-10-09 | 1280×720 PNG on viewport + `.pdf-page` | usable on the same Windows machine | 325 | 12 | 23 | 99 | 10 |
| `02-current-W1-raster-both.pdf` | current | 1280×720 PNG on viewport + `.pdf-page` | untested | 328 | 12 | 23 | 99 | 12 |
| `03-current-W2-flat-both.pdf` | current | flat color on viewport + `.pdf-page` | untested | 328 | 12 | 23 | 99 | 12 |

All four files preserve selectable text. The three current files preserve all 12 URI annotations.

## Test procedure

Use the same Windows machine and Acrobat installation that showed the regression.

1. Extract the ZIP locally; do not test inside the archive or through a browser preview.
2. Close Acrobat completely between cold tests.
3. Open each uniquely named PDF and record:
   - time until the first page is usable;
   - whether first navigation to later pages stalls;
   - whether revisiting pages is fast after caching;
   - any visible background artifacts.
4. Test in this order: `00`, `01`, `02`, `03`; then, if results are close, repeat in reverse order.

## Interpretation

- `01` fast and `02` fast: the missing print-viewport override caused the production regression.
- `01` fast, `02` slow: current slide content introduced another expensive operation despite matching aggregate object counts.
- `01` slow now: the Acrobat/system environment changed or the historical result was not stable.
- `02` slow, `03` fast: PNG decoding/reuse contributes materially; use flat or test another image representation.
- `02` and `03` both fast: adopt `02` because it preserves the intended appearance.
- `02` and `03` both slow while `01` is fast: inspect per-page content differences rather than background structure.
