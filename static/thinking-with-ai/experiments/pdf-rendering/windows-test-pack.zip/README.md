# PDF rendering experiment — 2026-09-25

## Purpose

Separate two suspected causes of slow first rendering in Windows Acrobat:

1. Chromium/Skia converts the variable Inter font into hundreds of PDF Type 3 font subsets.
2. The deck uses a full-page linear gradient, two translucent radial gradients, and many transparent panels.

The current PDF renders slowly once in Windows Acrobat, then switches pages quickly from cache. Linux is fast; macOS showed a few minor artifacts.

## Cells

| Cell | Font | Full-page background |
|---|---|---|
| A | `InterVariable` | live CSS gradients |
| B | static Inter TTF faces | live CSS gradients |
| C | `InterVariable` | one prerendered gradient image |
| D | static Inter TTF faces | one prerendered gradient image |
| E | `InterVariable`, optical sizing disabled | live CSS gradients |
| F | static Inter TTF faces, optical sizing disabled | live CSS gradients |

Run:

```bash
node experiments/pdf-rendering-2026-09-25/run.mjs
```

The script expects the official Inter 4.1 static TTF files under `fonts/`. They come from:

`https://github.com/rsms/inter/releases/download/v4.1/Inter-4.1.zip`

## Structural result

| Cell | Bytes | Type 3 fonts | InterVariable | Static Inter | Shadings | Patterns | ExtGState |
|---|---:|---:|---:|---:|---:|---:|---:|
| A variable + gradients | 2,638,797 | 324 | 323 | 0 | 282 | 748 | 257 |
| B static + gradients | 1,111,457 | 1 | 0 | 8 | 282 | 748 | 257 |
| C variable + image background | 2,834,245 | 324 | 323 | 0 | 272 | 722 | 253 |
| D static + image background | 1,307,060 | 1 | 0 | 8 | 272 | 722 | 253 |
| E variable, no optical sizing + gradients | 2,269,826 | 248 | 247 | 0 | 282 | 748 | 257 |
| F static, no optical sizing + gradients | 1,111,457 | 1 | 0 | 8 | 282 | 748 | 257 |

Static TTF faces remove 323 Type 3 Inter subsets and reduce PDF size by about 58%. Disabling variable-font optical sizing alone removes 76 Type 3 subsets but leaves 247. Prerendering only the full-page gradient removes 10 shading objects, 26 patterns, and 4 ExtGState objects, while increasing file size by about 7%.

## Important limitation

Static Inter changes line wrapping and spacing because the live variable font uses optical-size and intermediate-weight instances. The static-font cells are diagnostic, not production-ready. A future static-font PDF profile needs visual retuning or static instances matching the exact variable-font axes used by the deck.

Ghostscript timings on Linux were unstable across order and warm-cache runs, so they do not identify the Windows Acrobat bottleneck. The discriminating measurement is cold first-render time on the affected Windows machine for all uniquely named PDFs.

A brute-force compatibility control was generated with Ghostscript's `pdfimage24` device at 150 DPI. It contains one RGB image per page, no fonts, and is 3.23 MB. Linux Ghostscript rendered all 26 raster pages at 72 DPI in 1.56 seconds, much faster than the vector variants in that run. It sacrifices searchable/selectable text and PDF links, so it is a fallback/control rather than the preferred archival result.

## Primary-source context

Chromium states that Skia emits Type 3 fonts for variable-font instances:

`https://issues.chromium.org/issues/333276004`

Chromium issue 432633012 records Acrobat/PDFL rendering problems with Skia Type 3 output and is closed as intended behavior on the Chromium side:

`https://issues.chromium.org/issues/432633012`
