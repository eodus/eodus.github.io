# Windows PDF background fix candidates — 2026-10-09

Observed result: N is usable; O is slow.

DOM inspection found the exact difference. Reveal copies the viewport's three-layer gradient onto every generated `.pdf-page`
before the late experiment CSS runs. O still contains 26 page-level copies of:

```css
radial-gradient(...) , radial-gradient(...) , linear-gradient(...)
```

N removes every descendant `background-image`, including those `.pdf-page` gradients. Therefore the culprit is the repeated
three-layer full-page gradient, not Inter Type 3 fonts or component backgrounds. Earlier C/J cells were invalid background
replacements: they changed `.reveal-viewport` after Reveal had already copied its original gradient into `.pdf-page`.

## Candidates

| Cell | PDF-page background | Other component styling | Bytes | Type 3 | Shadings | Patterns | ExtGState | URI |
|---|---|---|---:|---:|---:|---:|---:|---:|
| P | one reused 1280×720 raster of the original gradient | original | 2,661,002 | 325 | 12 | 23 | 99 | 10 |
| Q | flat `#07111f` | original | 2,459,015 | 325 | 12 | 23 | 99 | 10 |

P applies the raster background to both `.reveal-viewport` and every `.pdf-page`, preserving the intended appearance,
variable-font layout, text, and links. The same image object is reused across pages. Q is the flat-background control.

Test P first on Windows. If P is usable, it is the production repair. Q confirms whether the raster image itself adds any
material cost.
