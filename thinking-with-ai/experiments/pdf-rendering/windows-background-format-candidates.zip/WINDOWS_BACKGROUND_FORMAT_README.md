# Windows PDF background format candidates — 2026-10-09

P (1280×720 PNG background) is usable and visually smoother than the native PDF gradient, but still requires noticeable
loading. Q is the flat-background baseline. These cells test image codec/resolution and simpler vector alternatives while
preserving the original component styling, variable-font layout, text, and ten URI annotations.

| Cell | PDF-page background | PDF bytes | Embedded background encoding/size | Shadings | Patterns | ExtGState |
|---|---|---:|---|---:|---:|---:|
| Q | flat `#07111f` | 2,459,015 | none | 12 | 23 | 99 |
| R | 1280×720 JPEG quality 95 | 2,482,361 | DCT/JPEG, 21.0 KB, reused | 12 | 23 | 99 |
| S | 640×360 PNG | 2,531,603 | lossless image, 69.1 KB, reused | 12 | 23 | 99 |
| T | 640×360 JPEG quality 90 | 2,464,560 | DCT/JPEG, 3.7 KB, reused | 12 | 23 | 99 |
| U | 1280×720 SVG with the original three gradients | 2,476,306 | vector conversion | 52 | 150 | 115 |
| V | one opaque CSS linear gradient | 2,468,896 | native PDF shading | 66 | 100 | 99 |

Google/primary-source result: Adobe recommends transparency flattening and raster/vector balancing for complex artwork;
Chromium has slow-render reports for PDFs with many paths. No reliable source establishes a universal PNG-versus-JPEG viewer
winner. PDF has no native SVG image codec, so SVG is converted back into vector/shading objects and risks recreating the
problem. JPEG is directly embedded with DCT compression and is materially smaller here; whether it reduces Windows viewer
startup must be measured.

Test order:

1. Q — maximum speed available without a background image.
2. R — same 1280×720 visual geometry as P, JPEG instead of PNG.
3. T — smallest decode candidate; inspect banding/artifacts.
4. S — lower-resolution lossless control.
5. V — simple opaque vector-gradient compromise.
6. U — SVG control; expected to be worse because it restores vector gradient machinery.

Prefer R if it materially improves loading without visible artifacts. Prefer P if JPEG does not help. Do not adopt U merely
because SVG sounds scalable; its generated PDF structure is what matters.
